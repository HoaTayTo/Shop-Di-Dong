@foreach ($img_rel as $rel)
    <p>{{ $rel->name }}</p>
@endforeach
