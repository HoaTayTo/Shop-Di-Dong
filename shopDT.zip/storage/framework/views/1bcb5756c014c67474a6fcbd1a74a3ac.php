<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('account.layout.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="banner2"><img src="<?php echo e(asset('Images_Logo/banner2.png')); ?>" alt=""></div>
    
    <div class="banner" style="width: 1300px; margin:-10px auto;">
        <img style="width: 1300px; margin:0 auto;" src="<?php echo e(asset('Images_Logo/flashsale.gif')); ?>" alt="">
    </div>
    <div class="container_items" style="background-color: #EC7C00">
        <div class="container_main_products">
            <div class="container_slider_main_products">
                <div class="main_products">
                    <?php $__currentLoopData = $products1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item_content">
                            <img src="./Image_products/<?php echo e($p1->img); ?>" alt="">
                            <div class="item_text">
                                <li><img src="./Image_products/icon_2.jpg" alt="">
                                    <p>Trợ giá hấp dẫn</p>
                                </li>
                                <li><a href="/detailsproduct/<?php echo e($p1->id); ?>">
                                        <h3><?php echo e($p1->name); ?></h3>
                                    </a></li>
                                <li><a href="#">Online giá rẻ</a></li>
                                <li><a
                                        href="/detailsproduct/<?php echo e($p1->id); ?>"><?php echo e(number_format($p1->getDiscountedPrice(), 0, ',', '.')); ?><sup>đ</sup></a>
                                </li>
                                <li><a href="">
                                        <del><?php echo e(number_format($p1->price, 0, '.', '.')); ?></del><sup>đ</sup></a><span>-<?php echo e($p1->sale); ?>%</span>
                                </li>
                                <li>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                </li>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="main_products">
                    <?php $__currentLoopData = $products2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item_content">
                            <img src="./Image_products/<?php echo e($p2->img); ?>" alt="">
                            <div class="item_text">
                                <li><img src="./Image_products/icon_2.jpg" alt="">
                                    <p>Trợ giá hấp dẫn</p>
                                </li>
                                <li><a href="/detailsproduct/<?php echo e($p2->id); ?>">
                                        <h3><?php echo e($p2->name); ?></h3>
                                    </a></li>
                                <li><a href="#">Online giá rẻ</a></li>
                                <li><a
                                        href="/detailsproduct/<?php echo e($p2->id); ?>"><?php echo e(number_format($p2->getDiscountedPrice(), 0, ',', '.')); ?><sup>đ</sup></a>
                                </li>
                                <li><a href="">
                                        <del><?php echo e(number_format($p2->price, 0, '.', '.')); ?></del><sup>đ</sup></a><span>-<?php echo e($p2->sale); ?>%</span>
                                </li>
                                <li>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                </li>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="main_products">
                    <?php $__currentLoopData = $products3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item_content">
                            <img src="./Image_products/<?php echo e($p3->img); ?>" alt="">
                            <div class="item_text">
                                <li><img src="./Image_products/icon_2.jpg" alt="">
                                    <p>Trợ giá hấp dẫn</p>
                                </li>
                                <li><a href="/detailsproduct/<?php echo e($p3->id); ?>">
                                        <h3><?php echo e($p1->name); ?></h3>
                                    </a></li>
                                <li><a href="#">Online giá rẻ</a></li>
                                <li><a
                                        href="/detailsproduct/<?php echo e($p3->id); ?>"><?php echo e(number_format($p3->getDiscountedPrice(), 0, ',', '.')); ?><sup>đ</sup></a>
                                </li>
                                <li><a href="">
                                        <del><?php echo e(number_format($p3->price, 0, '.', '.')); ?></del><sup>đ</sup></a><span>-<?php echo e($p3->sale); ?>%</span>
                                </li>

                                <li>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                </li>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <div class="btn_chevron_2">
            <i class="fas fa-chevron-left fa-chevron-left_2"></i>
            <i class="fas fa-chevron-right fa-chevron-right_2"></i>
        </div>
    </div>
    

    
    <div class="banner" style="width: 1300px; margin:-10px auto; margin-top:20px">
        <img style="width: 1300px; margin:0 auto;" src="<?php echo e(asset('Images_Logo/banner3.png')); ?>" alt="">
    </div>
    <div class="container_items_1" style="background-color: #EC7C00">
        <div class="container_main_products_1">
            <div class="container_slider_main_products_1">
                <div class="main_products_1">
                    <?php $__currentLoopData = $products1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item_content_1">
                            <img src="./Image_products/<?php echo e($p1->img); ?>" alt="">
                            <div class="item_text_1">
                                <li><img src="./Image_products/icon_2.jpg" alt="">
                                    <p>Trợ giá hấp dẫn</p>
                                </li>
                                <li><a href="/detailsproduct/<?php echo e($p1->id); ?>">
                                        <h3><?php echo e($p1->name); ?></h3>
                                    </a></li>
                                <li><a href="#">Online giá rẻ</a></li>
                                <li><a
                                        href="/detailsproduct/<?php echo e($p1->id); ?>"><?php echo e(number_format($p1->getDiscountedPrice(), 0, ',', '.')); ?><sup>đ</sup></a>
                                </li>
                                <li><a href="">
                                        <del><?php echo e(number_format($p1->price, 0, '.', '.')); ?></del><sup>đ</sup></a><span>-<?php echo e($p1->sale); ?>%</span>
                                </li>
                                <li>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                </li>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="main_products_1">
                    <?php $__currentLoopData = $products2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item_content_1">
                            <img src="./Image_products/<?php echo e($p2->img); ?>" alt="">
                            <div class="item_text_1">
                                <li><img src="./Image_products/icon_2.jpg" alt="">
                                    <p>Trợ giá hấp dẫn</p>
                                </li>
                                <li><a href="/detailsproduct/<?php echo e($p2->id); ?>">
                                        <h3><?php echo e($p2->name); ?></h3>
                                    </a></li>
                                <li><a href="#">Online giá rẻ</a></li>
                                <li><a
                                        href="/detailsproduct/<?php echo e($p2->id); ?>"><?php echo e(number_format($p2->getDiscountedPrice(), 0, ',', '.')); ?><sup>đ</sup></a>
                                </li>
                                <li><a href="">
                                        <del><?php echo e(number_format($p2->price, 0, '.', '.')); ?></del><sup>đ</sup></a><span>-<?php echo e($p2->sale); ?>%</span>
                                </li>
                                <li>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                </li>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="main_products_1">
                    <?php $__currentLoopData = $products3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item_content_1">
                            <img src="./Image_products/<?php echo e($p1->img); ?>" alt="">
                            <div class="item_text_1">
                                <li><img src="./Image_products/icon_2.jpg" alt="">
                                    <p>Trợ giá hấp dẫn</p>
                                </li>
                                <li><a href="/detailsproduct/<?php echo e($p1->id); ?>">
                                        <h3><?php echo e($p1->name); ?></h3>
                                    </a></li>
                                <li><a href="#">Online giá rẻ</a></li>
                                <li><a
                                        href="/detailsproduct/<?php echo e($p1->id); ?>"><?php echo e(number_format($p1->getDiscountedPrice(), 0, ',', '.')); ?><sup>đ</sup></a>
                                </li>
                                <li><a href="">
                                        <del><?php echo e(number_format($p1->price, 0, '.', '.')); ?></del><sup>đ</sup></a><span>-<?php echo e($p1->sale); ?>%</span>
                                </li>
                                <li>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                </li>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <div class="btn_chevron_3">
            <i class="fas fa-chevron-left fa-chevron-left_3"></i>
            <i class="fas fa-chevron-right fa-chevron-right_3"></i>
        </div>
        <div class="button_show_all"> <button name="show_all"><a href="#">Xem thêm kết quả</a></button> </div>

    </div>
    


    
    <div class="banner" style="width: 1300px; margin:-10px auto; margin-top:20px">
        <img style="width: 1300px; margin:0 auto;" src="<?php echo e(asset('Images_Logo/banner4.png')); ?>" alt="">
    </div>
    <div class="container_items_2" style="background-color: #920101">
        <div class="container_main_products_2">
            <div class="container_slider_main_products_2">
                <div class="main_products_2">
                    <?php $__currentLoopData = $products2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item_content_2">
                            <img src="./Image_products/<?php echo e($p2->img); ?>" alt="">
                            <div class="item_text_2">
                                <li><img src="./Image_products/icon_2.jpg" alt="">
                                    <p>Trợ giá hấp dẫn</p>
                                </li>
                                <li><a href="/detailsproduct/<?php echo e($p2->id); ?>">
                                        <h3><?php echo e($p2->name); ?></h3>
                                    </a></li>
                                <li><a href="#">Online giá rẻ</a></li>
                                <li><a
                                        href="/detailsproduct/<?php echo e($p2->id); ?>"><?php echo e(number_format($p2->getDiscountedPrice(), 0, ',', '.')); ?><sup>đ</sup></a>
                                </li>
                                <li><a href="">
                                        <del><?php echo e(number_format($p2->price, 0, '.', '.')); ?></del><sup>đ</sup></a><span>-<?php echo e($p2->sale); ?>%</span>
                                </li>
                                <li>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                </li>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="main_products_2">
                    <?php $__currentLoopData = $products2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item_content_2">
                            <img src="./Image_products/<?php echo e($p2->img); ?>" alt="">
                            <div class="item_text_2">
                                <li><img src="./Image_products/icon_2.jpg" alt="">
                                    <p>Trợ giá hấp dẫn</p>
                                </li>
                                <li><a href="/detailsproduct/<?php echo e($p2->id); ?>">
                                        <h3><?php echo e($p2->name); ?></h3>
                                    </a></li>
                                <li><a href="#">Online giá rẻ</a></li>
                                <li><a
                                        href="/detailsproduct/<?php echo e($p2->id); ?>"><?php echo e(number_format($p2->getDiscountedPrice(), 0, ',', '.')); ?><sup>đ</sup></a>
                                </li>
                                <li><a href="">
                                        <del><?php echo e(number_format($p2->price, 0, '.', '.')); ?></del><sup>đ</sup></a><span>-<?php echo e($p2->sale); ?>%</span>
                                </li>
                                <li>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                </li>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="main_products_2">
                    <?php $__currentLoopData = $products2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item_content_2">
                            <img src="./Image_products/<?php echo e($p2->img); ?>" alt="">
                            <div class="item_text_2">
                                <li><img src="./Image_products/icon_2.jpg" alt="">
                                    <p>Trợ giá hấp dẫn</p>
                                </li>
                                <li><a href="/detailsproduct/<?php echo e($p2->id); ?>">
                                        <h3><?php echo e($p2->name); ?></h3>
                                    </a></li>
                                <li><a href="#">Online giá rẻ</a></li>
                                <li><a
                                        href="/detailsproduct/<?php echo e($p2->id); ?>"><?php echo e(number_format($p2->getDiscountedPrice(), 0, ',', '.')); ?><sup>đ</sup></a>
                                </li>
                                <li><a href="">
                                        <del><?php echo e(number_format($p2->price, 0, '.', '.')); ?></del><sup>đ</sup></a><span>-<?php echo e($p2->sale); ?>%</span>
                                </li>
                                <li>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                </li>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <div class="btn_chevron_4">
            <i class="fas fa-chevron-left fa-chevron-left_4"></i>
            <i class="fas fa-chevron-right fa-chevron-right_4"></i>
        </div>
    </div>
    


    
    
    
    <section class="buy_trend">
        <div class="container_buy_trend">
            <div class="content_title"><strong>XU HƯỚNG MUA SẮM</strong></div>
            <div class="xu_huong_mua_sam">
                <div class="main_content_buy_trend">
                    <img src="./Images_Logo/trend1.webp" alt="">
                    <div class="content_text">
                        <h3>iPhone 11</h3>
                        <strong>Chỉ từ 8.990.000 <sup>đ</sup></strong>
                    </div>
                </div>
                <div class="main_content_buy_trend">
                    <img src="./Images_Logo/trend2.webp" alt="">
                    <div class="content_text">
                        <h3>Laptop Gaming</h3>
                        <strong>Chỉ từ 15.990.000 <sup>đ</sup></strong>
                    </div>
                </div>
                <div class="main_content_buy_trend">
                    <img src="./Images_Logo/trend3.webp" alt="">
                    <div class="content_text">
                        <h3>Sạc dự phòng giá rẻ</h3>
                        <strong>Chỉ từ 190.000 <sup>đ</sup></strong>
                    </div>
                </div>
                <div class="main_content_buy_trend">
                    <img src="./Images_Logo/trend4.webp" alt="">
                    <div class="content_text">
                        <h3>Xiaomi Watch mới</h3>
                        <strong>Chỉ từ 1.590.000 <sup>đ</sup></strong>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="gallery">
        <div class="container_gallery">
            <div class="title_gallery"><strong>DANH MỤC NỔI BẬT</strong></div>
            <div class="contain_gallery">
                <?php $__currentLoopData = $category_trend; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ctg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="content_gallery">
                        <img src="./Images_Logo/<?php echo e($ctg->link); ?>" alt="">
                        <span><?php echo $ctg->name; ?></span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <!-- ----------------------------------DỊCH VỤ TIỆN ÍCH---------------------- -->
        <section class="dich_vu_tien-ich">
            <div class="container_service">
                <div class="content_service">
                    <img src="<?php echo e(asset('Images_Logo/banner6.png')); ?>" alt="">
                </div>
            </div>
        </section>
        <section class="suggestion">
            <div class="container_suggestion">
                <div class="title_gallery"><strong>GỢI Ý HÔM NAY</strong></div>
                <div class="title_suggestion">
                    <img src="<?php echo e(asset('Images_Logo/banner7.png')); ?>" alt="">
                    <img src="<?php echo e(asset('Images_Logo/banner8.png')); ?>" alt="">
                    <img src="<?php echo e(asset('Images_Logo/banner9.png')); ?>" alt="">
                    <img src="<?php echo e(asset('Images_Logo/banner10.png')); ?>" alt="">
                </div>
            </div>
        </section>
        <div class="container_content">
            <?php $__currentLoopData = $products1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="content_items">
                    <img src="/Image_products/<?php echo e($p3->img); ?>" alt="">

                    <li><a href="/detailsproduct/<?php echo e($p3->id); ?>">
                            <h3><?php echo e($p3->name); ?></h3>
                        </a></li>
                    <li><a href="#">Online giá rẻ</a></li>
                    <li><a
                            href="/detailsproduct/<?php echo e($p3->id); ?>"><?php echo e(number_format($p3->getDiscountedPrice(), 0, ',', '.')); ?><sup>đ</sup></a>
                    </li>
                    <li><a href="">
                            <del><?php echo e(number_format($p3->price, 0, '.', '.')); ?></del><sup>đ</sup></a><span>-<?php echo e($p3->sale); ?>%</span>
                    </li>
                    <li>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </li>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="clock_model">
            <img src="<?php echo e(asset('Images_Logo/banner11.png')); ?>" alt="">
        </div>
        <div class="container_suggestion">
            <div class="title_gallery"><strong>CHUYÊN TRANG CÔNG NGHỆ</strong></div>
            <div class="page_tech">
                <a href="/"><img src="<?php echo e(asset('Images_Logo/banner12.png')); ?>" alt=""></a>
                <a href="/"> <img src="<?php echo e(asset('Images_Logo/banner13.png')); ?>" alt=""></a>
                <a href="/"><img src="<?php echo e(asset('Images_Logo/banner14.png')); ?>" alt=""></a>
            </div>
        </div>
        <div class="container_suggestion">
            <div class="title_gallery"><strong>CHUỖI MỚI DEAL KHỦNG</strong></div>
            <div class="page_tech">
                <a href="/"><img src="<?php echo e(asset('Images_Logo/banner15.png')); ?>" alt=""></a>
                <a href="/"> <img src="<?php echo e(asset('Images_Logo/banner16.png')); ?>" alt=""></a>
                <a href="/"><img src="<?php echo e(asset('Images_Logo/banner17.png')); ?>" style="height: 221.05px" alt=""></a>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('account.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Shop\shopDT\resources\views/account/product/home.blade.php ENDPATH**/ ?>