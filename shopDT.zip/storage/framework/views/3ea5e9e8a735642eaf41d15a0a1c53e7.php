<section class="slider">
    <div class="container_slider">
        <div class="slider_content">
            <div class="slider_content_left">
                <div class="container_left_top">
                    <div class="slider_content_left_top">
                        <a href="#"><img src="./Images_Logo/slider1.webp" alt=""></a>
                        <a href="#"><img src="./Images_Logo/slider2.webp" alt=""></a>
                        <a href="#"><img src="./Images_Logo/slider3.webp" alt=""></a>
                        <a href="#"><img src="./Images_Logo/slider4.webp" alt=""></a>
                    </div>
                    <div class="btn_chevron">
                        <i class="fas fa-chevron-left"></i>
                        <i class="fas fa-chevron-right"></i>
                    </div>
                </div>
                <div class="slider_content_left_bottom">
                    <li class="active"><a href="#">Đổi 2G lên Smartphone 4G</a></li>
                    <li><a href="#">Đồng hồ giá sốc</a></li>
                    <li><a href="#">Giảm từ 25% Từ 12.29 triệu</a></li>
                    <li><a href="#">Giảm đến 50%++</a></li>
                </div>
            </div>
            <div class="slider_content_right">

                <!-- <li><a href=""><img src="./Images_Logo/img2.webp" alt=""></a></li>
                    <li><a href=""><img src="./Images_Logo/img3.webp" alt=""></a></li>
                    <li><a href=""><img src="./Images_Logo/img4.webp" alt=""></a></li> -->
                <div class="img"><a href="#"><img src="./Images_Logo/img1.webp" alt=""></a></div>
                <div class="img"><a href="#"><img src="./Images_Logo/img2.webp" alt=""></a></div>
                
            </div>
        </div>
    </div>
</section>
<?php /**PATH C:\xampp\htdocs\Shop\shopDT\resources\views/account/layout/slider.blade.php ENDPATH**/ ?>